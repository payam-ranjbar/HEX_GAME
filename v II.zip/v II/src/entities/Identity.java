package entities;

public enum Identity {
    redPerson,
    bluePerson,
    redAI,
    blueAI;
}
