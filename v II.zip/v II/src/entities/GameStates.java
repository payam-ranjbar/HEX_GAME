package entities;

public enum GameStates {
    play,
    exit,
    restart,
}
