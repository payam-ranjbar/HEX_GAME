package entities;

public enum GameModes {
    PersonVsPerson,
    PersonVsAI,
    AIvsPerson,
    AIvsAI;
}
