import controller.TheGame;

public class RUN_HERE {
    public static void main(String[] args) {
        TheGame game = new TheGame();
    }
}
